export const IMAGE_URL = 'https://raw.githubusercontent.com/binaryprotagonist/adyproductiondevelopmenttask/gh-pages/img'
