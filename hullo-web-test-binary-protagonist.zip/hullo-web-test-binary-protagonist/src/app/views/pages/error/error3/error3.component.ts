import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-error3',
  templateUrl: './error3.component.html',
  styleUrls: ['./../../../../../assets/sass/pages/error/error-3.scss']
})
export class Error3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
