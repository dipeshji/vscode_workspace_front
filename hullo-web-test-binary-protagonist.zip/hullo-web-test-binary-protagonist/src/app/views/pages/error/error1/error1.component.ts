import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-error1',
  templateUrl: './error1.component.html',
  styleUrls: ['./error1.component.scss']
})
export class Error1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
