import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
// Core Module
import { CoreModule } from '../../../core/core.module';
import { PartialsModule } from '../../partials/partials.module';
import { SubscriptionComponent } from './subscription.component';

@NgModule({
  declarations: [SubscriptionComponent],
  imports: [
    CommonModule,
    CoreModule,
    PartialsModule,
    RouterModule.forChild([
      {
        path: '',
        component: SubscriptionComponent
      },
    ]),
  ]
})
export class SubscriptionModule { }
