import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit, ChangeDetectorRef, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { select, Store } from '@ngrx/store';
import { MatSnackBar } from '@angular/material/snack-bar';
// State
import { AppState } from '../../../core/reducers';
import { currentUser, AccountService, UpdatePhoneNumber } from '../../../core/auth';

declare var stripe: any;
declare var elements: any;

@Component({
  selector: 'kt-subscription',
  templateUrl: './subscription.component.html',
  styleUrls: ['./subscription.component.scss']
})
export class SubscriptionComponent implements OnInit, OnDestroy, AfterViewInit {
  private _destroyed = new Subject<void>();

  userSubscriptions = [];
  @ViewChild('cardInfo', { static: false }) cardInfo: ElementRef;
  card: any;
  cardHandler = this.onCardChange.bind(this);
  cardError: string;

  planSelected = false;

  constructor(
    private router: Router,
    private cd: ChangeDetectorRef,
    private snackBar: MatSnackBar,
    private store: Store<AppState>,
    private accountService: AccountService
  ) { }

  ngOnInit(): void {
    this.store.pipe(
      takeUntil(this._destroyed),
      select(currentUser),
      tap(userState => {
        this.userSubscriptions = userState?.subscriptions || [];
      })
    ).subscribe();
  }

  ngAfterViewInit(): void {
    const style = {
      base: {
        icon: false,
        color: '#32325d',
        fontFamily: 'monospace, sans-serif',
        fontSmoothing: 'antialiased',
        fontSize: '15px',
        '::placeholder': {
          color: '#a6a6a6'
        }
      },
      invalid: {
        color: '#fa755a',
        iconColor: '#fa755a'
      }
    };

    this.card = elements.create('card', { style });
    this.card.mount(this.cardInfo.nativeElement);
    this.card.addEventListener('change', this.cardHandler);
  }

  ngOnDestroy(): void {
    this.card.removeEventListener('change', this.cardHandler);
    this.card.destroy();
    this._destroyed.next();
    this._destroyed.complete();
  }

  onCardChange({ error }) {
    if (error) {
      this.cardError = error.message;
    } else {
      this.cardError = null;
    }
    this.cd.detectChanges();
  }

  selectPlan(plan): void {
    if (this.userSubscriptions.length) {
      this.userSubscriptions = [plan];
      this.updatePlan();
    } else {
      this.planSelected = true;
      this.userSubscriptions.push(plan);
    }
  }

  async purchasePlan() {
    const { token, error } = await stripe.createToken(this.card);
    if (token) {
      const postData = {
        stripe_token: token.id,
        stripe_plans: this.userSubscriptions
      };
      this.accountService.purchasePlans(postData).subscribe(() => {
        this.snackBar.open('You have purchased a plan', 'Got it!');
      });
    } else {
      this.cardError = error.message;
    }
  }

  updatePlan(): void {
    const postData = {
      stripe_token: null,
      stripe_plans: this.userSubscriptions
    };
    this.accountService.purchasePlans(postData).subscribe(() => {
      this.snackBar.open('You have updated your subscription', 'Got it!');
    });
  }

  unsubscribe(): void {
    this.userSubscriptions = [];
    this.updatePlan();
  }
}
