import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { select, Store } from '@ngrx/store';
import { MatSnackBar } from '@angular/material/snack-bar';
// State
import { AppState } from '../../../../core/reducers';
import { currentUser, AccountService, SaveProfile, Logout } from '../../../../core/auth';
import { ConfirmPasswordValidator } from '../../auth/register/confirm-password.validator';

@Component({
  selector: 'kt-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit, OnDestroy {
  private _destroyed = new Subject<void>();
  form: FormGroup;
  passwordForm: FormGroup;
  userState: any;

  constructor(
    private store: Store<AppState>,
    private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    private accountService: AccountService
  ) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      accountName: [null, Validators.required],
      address: [null],
      city: [null],
      state: [null],
      zip: [null],
      firstName: [null, Validators.required],
      lastName: [null, Validators.required],
      email: [null, Validators.required]
    });
    this.passwordForm = this.formBuilder.group({
      oldPassword: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    }, {
      validator: ConfirmPasswordValidator.MatchPassword
    });

    this.store.pipe(
      takeUntil(this._destroyed),
      select(currentUser)
    ).subscribe(userState => {
      if (userState) {
        this.userState = userState;
        this.form.patchValue({
          accountName: userState.account?.name,
          address: userState.account?.address,
          city: userState.account?.city,
          state: userState.account?.state,
          zip: userState.account?.zip,
          firstName: userState.user?.firstName,
          lastName: userState.user?.lastName,
          email: userState.user?.email
        });
      }
    });
  }

  ngOnDestroy(): void {
    this._destroyed.next();
    this._destroyed.complete();
  }

  updateProfile(): void {
    const user = Object.assign({}, this.userState.user);
    const account = Object.assign({}, this.userState.account);
    account.name = this.form.controls.accountName.value;
    account.address = this.form.controls.address.value;
    account.city = this.form.controls.city.value;
    account.state = this.form.controls.state.value;
    account.zip = this.form.controls.zip.value;
    user.firstName = this.form.controls.firstName.value;
    user.lastName = this.form.controls.lastName.value;
    user.email = this.form.controls.email.value;

    this.accountService.updateAccount(user, account).pipe(
      tap(() => {
        this.form.markAsPristine();
        this.store.dispatch(new SaveProfile({account, user}));
        this.snackBar.open('We updated your profile.', 'Got it!');
      }),
      takeUntil(this._destroyed)
    ).subscribe();
  }

  changePassword(): void {
    const oldPassword = this.passwordForm.controls.oldPassword.value;
    const password = this.passwordForm.controls.password.value;
    this.accountService.changePassword(oldPassword, password).pipe(
      tap((resp: any) => {
        if (resp.pwdchanged) {
          this.store.dispatch(new Logout());
        } else {
          this.passwordForm.reset();
          this.passwordForm.markAsPristine();
          this.snackBar.open('Something went wrong and we could not change your password.', 'Ok');
        }
      }),
      takeUntil(this._destroyed)
    ).subscribe();
  }
}
