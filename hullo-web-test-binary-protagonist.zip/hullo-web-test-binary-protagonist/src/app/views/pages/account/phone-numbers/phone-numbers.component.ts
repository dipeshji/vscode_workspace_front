import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// Material
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatSnackBar } from '@angular/material/snack-bar';
// RXJS
import { Observable, of, Subject } from 'rxjs';
import { tap, takeUntil } from 'rxjs/operators';
// MOMENT
import * as moment from 'moment';
// NGRX
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../../core/reducers';
import { currentUser, AccountService, UpdatePhoneNumber, BuyPhoneNumber, ReleasePhoneNumber } from '../../../../core/auth';
// Services
import { LayoutUtilsService, MessageType, QueryParamsModel } from '../../../../core/_base/crud';

@Component({
  selector: 'kt-phone-numbers',
  templateUrl: './phone-numbers.component.html',
  styleUrls: ['./phone-numbers.component.scss']
})
export class PhoneNumbersComponent implements OnInit, OnDestroy {
  private _destroyed = new Subject<void>();
  phoneNumbers = [];
  isLoading$: Observable<boolean> = of(true);
  displayedColumns = ['id', 'phone_code', 'campname', 'ivrname', 'created_at', 'actions'];

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild('sort', { static: true }) sort: MatSort;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private store: Store<AppState>,
    private snackBar: MatSnackBar,
    private layoutUtilsService: LayoutUtilsService,
    private accountService: AccountService
  ) { }

  ngOnInit(): void {
    this.store.pipe(
      takeUntil(this._destroyed),
      select(currentUser)
    ).subscribe(userState => {
      this.phoneNumbers = userState?.phone_code_numbers || [];
      const campaigns = userState?.tceCampaign || [];
      const ivrs = userState?.ivrCommTreeHead || [];
      this.phoneNumbers = this.phoneNumbers.map(p => {
        const phone = Object.assign({}, p);
        const campaign = campaigns.find(c => c.id === phone.tceCampaign_id);
        phone.campname = campaign ? campaign.name : '';
        const ivr = ivrs.find(iv => iv.id === phone.ivrCommTreeHead_id);
        phone.ivrname = ivr ? ivr.name : '';
        phone.created_at = moment(phone.created_at).format('MMM Do YY');

        return phone;
      });
      this.isLoading$ = of(false);
    });
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);
  }

  ngOnDestroy(): void {
    this._destroyed.next();
    this._destroyed.complete();
  }

  editPhone(id): void {
    this.router.navigate(['/account/phone-numbers', id]);
  }

  releasePhone(phoneNumber): void {
    const _title = 'Release Phone Number';
    const _description = 'Are you sure to release this phone number?';
    const _waitDesciption = 'Phone number is being released...';
    const _releaseMessage = 'Phone number has been released';

    const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      this.isLoading$ = of(true);
      this.accountService.releasePhoneNumber(phoneNumber).pipe(
        takeUntil(this._destroyed),
        tap(() => {
          this.isLoading$ = of(false);
          this.store.dispatch(new ReleasePhoneNumber({ phoneNumber }));
          this.layoutUtilsService.showActionNotification(_releaseMessage, MessageType.Delete, 2000, true, false);
        }, () => {
          this.isLoading$ = of(false);
        })
      ).subscribe();
    });
  }

  buyNumber(): void {
    const _title = 'Purchase Phone Number';
    const _description = 'Are you sure to purchase a phone number?';
    const _waitDesciption = 'Trying to purchase a phone number...';

    const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
    dialogRef.afterClosed().subscribe(res => {
      if (!res) return;

      this.isLoading$ = of(true);
      this.accountService.buyPhoneNumber().pipe(
        takeUntil(this._destroyed),
        tap(() => {
          this.isLoading$ = of(false);
          window.location.reload();
        })
      ).subscribe();
    });
  }
}
