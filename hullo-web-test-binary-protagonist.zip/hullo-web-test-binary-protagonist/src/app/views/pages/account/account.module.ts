// Angular
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// Core Module
import { CoreModule } from '../../../core/core.module';
import { PartialsModule } from '../../partials/partials.module';
// Routing
import { AccountRoutingModule } from './account-routing.module';
import { AccountComponent } from './account.component';
import { ProfileComponent } from './profile/profile.component';
import { PhoneNumbersComponent } from './phone-numbers/phone-numbers.component';
import { SftpConfigComponent } from './sftp-config/sftp-config.component';
import { PhoneNumberEditComponent } from './phone-number-edit/phone-number-edit.component';

@NgModule({
  imports: [
    CommonModule,
    CoreModule,
    PartialsModule,
    AccountRoutingModule,
  ],
  providers: [],
  declarations: [
    AccountComponent,
    ProfileComponent,
    PhoneNumbersComponent,
    SftpConfigComponent,
    PhoneNumberEditComponent,
  ]
})
export class AccountModule {
}
