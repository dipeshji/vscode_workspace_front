// Angular
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountComponent } from './account.component';
import { ProfileComponent } from './profile/profile.component';
import { PhoneNumbersComponent } from './phone-numbers/phone-numbers.component';
import { PhoneNumberEditComponent } from './phone-number-edit/phone-number-edit.component';
import { SftpConfigComponent } from './sftp-config/sftp-config.component';

const routes: Routes = [
  {
    path: 'profile',
    component: ProfileComponent
  },
  {
    path: 'phone-numbers',
    component: PhoneNumbersComponent
  },
  {
    path: 'phone-numbers/:id',
    component: PhoneNumberEditComponent
  },
  {
    path: 'sftp',
    component: SftpConfigComponent
  },
  {
    path: '**',
    redirectTo: '',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AccountRoutingModule { }
