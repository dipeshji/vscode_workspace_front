import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SftpConfigComponent } from './sftp-config.component';

describe('SftpConfigComponent', () => {
  let component: SftpConfigComponent;
  let fixture: ComponentFixture<SftpConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SftpConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SftpConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
