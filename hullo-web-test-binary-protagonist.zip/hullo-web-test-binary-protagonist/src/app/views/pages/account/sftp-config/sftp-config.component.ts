import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { select, Store } from '@ngrx/store';
import { MatSnackBar } from '@angular/material/snack-bar';
// State
import { AppState } from '../../../../core/reducers';
import { currentUser, AccountService, SaveSftpKey } from '../../../../core/auth';

@Component({
  selector: 'kt-sftp-config',
  templateUrl: './sftp-config.component.html',
  styleUrls: ['./sftp-config.component.scss']
})
export class SftpConfigComponent implements OnInit, OnDestroy {
  private _destroyed = new Subject<void>();
  form: FormGroup;
  userState: any;

  constructor(
    private store: Store<AppState>,
    private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    private accountService: AccountService
  ) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      sftpPublicKey: [null, Validators.required]
    });
    this.store.pipe(
      takeUntil(this._destroyed),
      select(currentUser)
    ).subscribe(userState => {
      if (userState) {
        this.userState = userState;
        this.form.patchValue({
          sftpPublicKey: this.userState.account.SSHPublicKey1
        });
      }
    });
  }

  ngOnDestroy(): void {
    this._destroyed.next();
    this._destroyed.complete();
  }

  updateSftpConfig(): void {
    const SSHPublicKey1 = this.form.controls.sftpPublicKey.value;
    const UserName = this.userState?.user.email.replace(/[^\w\s]/gi, '');
    this.accountService.saveSftpKey({ SSHPublicKey1, UserName }).pipe(
      tap((response: any) => {
        this.form.markAsPristine();
        this.store.dispatch(new SaveSftpKey({ data: response }));
        this.snackBar.open('We saved yoru SFTP key.', 'Got it!');
      }),
      takeUntil(this._destroyed)
    ).subscribe();
  }
}
