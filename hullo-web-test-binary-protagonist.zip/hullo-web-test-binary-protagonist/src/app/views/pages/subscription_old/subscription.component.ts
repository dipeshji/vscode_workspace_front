import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit, ChangeDetectorRef, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { select, Store } from '@ngrx/store';
import { MatSnackBar } from '@angular/material/snack-bar';
// State
import { AppState } from '../../../core/reducers';
import { currentUser, AccountService, UpdatePhoneNumber } from '../../../core/auth';

declare var stripe: any;
declare var elements: any;

@Component({
  selector: 'kt-subscription',
  templateUrl: './subscription.component.html',
  styleUrls: ['./subscription.component.scss']
})
export class SubscriptionComponent implements OnInit, OnDestroy, AfterViewInit {
  private _destroyed = new Subject<void>();

  userSubscriptions = [];
  @ViewChild('cardInfo', { static: false }) cardInfo: ElementRef;
  card: any;
  cardHandler = this.onCardChange.bind(this);
  cardError: string;

  subscriptionPlans = null;
  subscriptionCategories = [];
  selectedCategory = null;
  selectedPlans = [];
  subtotal = 0;
  purchasedPlans = false;

  constructor(
    private router: Router,
    private cd: ChangeDetectorRef,
    private snackBar: MatSnackBar,
    private store: Store<AppState>,
    private accountService: AccountService
  ) { }

  ngOnInit(): void {
    this.store.pipe(
      takeUntil(this._destroyed),
      select(currentUser),
      tap(userState => {
        this.userSubscriptions = userState?.subscriptions || [];
      })
    ).subscribe();
    this.accountService.getSubscriptionPlans().subscribe(plans => {
      this.subscriptionPlans = {};
      plans.forEach(plan => {
        if (!this.subscriptionPlans.hasOwnProperty(plan.category)) {
          this.subscriptionPlans[plan.category] = [];
        }
        this.subscriptionPlans[plan.category].push(plan);
      });
      this.subscriptionCategories = Object.keys(this.subscriptionPlans);

      if (this.userSubscriptions.length) {
        this.purchasedPlans = true;
        for (let category in this.subscriptionPlans) {
          const plans = this.subscriptionPlans[category];
          const purchased = plans.find(p => this.userSubscriptions.includes(p.stripe_plan_id));
          if (!purchased) continue;
          const exists = this.selectedPlans.find(p => p.stripe_plan_id === purchased.stripe_plan_id);
          if (purchased && !exists) {
            this.selectedPlans.push(purchased);
          }
        }
        this.subtotal = this.selectedPlans.reduce((prev, plan) => prev + parseFloat(plan.price), 0);
      }
    });
  }

  ngAfterViewInit(): void {
    const style = {
      base: {
        icon: false,
        color: '#32325d',
        fontFamily: 'monospace, sans-serif',
        fontSmoothing: 'antialiased',
        fontSize: '15px',
        '::placeholder': {
          color: '#a6a6a6'
        }
      },
      invalid: {
        color: '#fa755a',
        iconColor: '#fa755a'
      }
    };

    this.card = elements.create('card', { style });
    this.card.mount(this.cardInfo.nativeElement);
    this.card.addEventListener('change', this.cardHandler);
  }

  ngOnDestroy(): void {
    this.card.removeEventListener('change', this.cardHandler);
    this.card.destroy();
    this._destroyed.next();
    this._destroyed.complete();
  }

  onCardChange({ error }) {
    if (error) {
      this.cardError = error.message;
    } else {
      this.cardError = null;
    }
    this.cd.detectChanges();
  }

  async purchase() {
    const { token, error } = await stripe.createToken(this.card);
    if (token) {
      const stripe_plans = this.selectedPlans.map(p => p.stripe_plan_id);
      const postData = {
        stripe_token: token.id,
        stripe_plans
      };
      this.accountService.purchasePlans(postData).subscribe(() => {
        this.purchasedPlans = true;
        this.snackBar.open('You have purchased a plan', 'Confirm');
      });
    } else {
      this.cardError = error.message;
    }
  }

  updatePurchase(): void {
    const stripe_plans = this.selectedPlans.map(p => p.stripe_plan_id);
    const postData = {
      stripe_token: null,
      stripe_plans
    };
    this.accountService.purchasePlans(postData).subscribe(() => {
      this.purchasedPlans = !!this.selectedPlans.length;
      this.snackBar.open('You have updated your subscription', 'Confirm');
    });
  }

  selectCategory(category): void {
    this.selectedCategory = this.subscriptionPlans[category];
  }

  selectPlan(plan): void {
    const dupIndex = this.selectedPlans.findIndex(p => p.category === plan.category);
    if (dupIndex > -1) {
      this.selectedPlans.splice(dupIndex, 1);
    }
    this.selectedPlans.push(plan);
    this.subtotal = this.selectedPlans.reduce((prev, plan) => prev + parseFloat(plan.price), 0);
  }
  unsubscribe(plan): void {
    const planIndex = this.selectedPlans.findIndex(p => p.category === plan.category);
    if (planIndex > -1) {
      this.selectedPlans.splice(planIndex, 1);
    }
    this.subtotal = this.selectedPlans.reduce((prev, plan) => prev + parseFloat(plan.price), 0);
    this.updatePurchase();
  }
}
