// Angular
import { Component } from '@angular/core';

@Component({
	selector: 'kt-order-edit',
	templateUrl: './order-edit.component.html'
})
export class OrderEditComponent { }
