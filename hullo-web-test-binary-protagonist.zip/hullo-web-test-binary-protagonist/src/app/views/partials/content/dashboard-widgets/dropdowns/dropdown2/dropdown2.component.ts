// Angular
import { Component } from '@angular/core';

@Component({
  selector: 'kt-dropdown2',
  templateUrl: './dropdown2.component.html',
})
export class Dropdown2Component {
}
