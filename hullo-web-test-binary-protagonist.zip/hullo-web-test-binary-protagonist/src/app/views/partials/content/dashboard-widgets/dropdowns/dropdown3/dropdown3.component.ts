// Angular
import { Component } from '@angular/core';

@Component({
  selector: 'kt-dropdown3',
  templateUrl: './dropdown3.component.html'
})
export class Dropdown3Component {
}
