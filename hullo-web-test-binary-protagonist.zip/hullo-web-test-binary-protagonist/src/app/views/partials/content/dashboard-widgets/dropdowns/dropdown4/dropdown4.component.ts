// Angular
import { Component } from '@angular/core';

@Component({
  selector: 'kt-dropdown4',
  templateUrl: './dropdown4.component.html'
})
export class Dropdown4Component {
}
