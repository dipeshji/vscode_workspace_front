// Actions
import { AuthActions, AuthActionTypes } from '../_actions/auth.actions';
// Models
import { User } from '../_models/user.model';

export interface AuthState {
  loggedIn: boolean;
  authToken: string;
  user: any;
  isUserLoaded: boolean;
  userProfile:any;
}

export const initialAuthState: AuthState = {
  loggedIn: false,
  authToken: undefined,
  user: undefined,
  isUserLoaded: false,
  userProfile:undefined

};

export function authReducer(state = initialAuthState, action: AuthActions): AuthState {
  switch (action.type) {
    case AuthActionTypes.Login: {
      const token: string = action.payload.authToken;
      return {
        loggedIn: true,
        authToken: token,
        user: undefined,
        isUserLoaded: false,
        userProfile:undefined
      };
    }

    case AuthActionTypes.Register: {
      const token: string = action.payload.authToken;
      return {
        loggedIn: true,
        authToken: token,
        user: undefined,
        isUserLoaded: false,
        userProfile:undefined
      };
    }

    case AuthActionTypes.Logout:
      return initialAuthState;

    case AuthActionTypes.UserLoaded: {
      const user: any = action.payload.user;
      return {
        ...state,
        user,
        isUserLoaded: true
      };
    }

    case AuthActionTypes.SaveProfile: {
      const account: any = action.payload.account;
      const user: any = action.payload.user;
      return {
        ...state,
        user: {
          ...state.user,
          account,
          user
        },
        isUserLoaded: true
      }
    }
    case AuthActionTypes.addProfile: {
      const userProfile: any = action.payload.userProfile;
      return {
        ...state,
        userProfile: {
          ...state.userProfile,
          userProfile
          
          
        },
        isUserLoaded: true
      }
    }

    case AuthActionTypes.UpdatePhoneNumber: {
      const phoneNumber: any = action.payload.phoneNumber;
      const phone_code_numbers = [...state.user.phone_code_numbers];
      const pIndex = phone_code_numbers.findIndex(p => p.id === phoneNumber.id);
      phone_code_numbers[pIndex] = phoneNumber;
      return {
        ...state,
        user: {
          ...state.user,
          phone_code_numbers
        },
        isUserLoaded: true
      }
    }

    case AuthActionTypes.ReleasePhoneNumber: {
      const phoneNumber: any = action.payload.phoneNumber;
      const phone_code_numbers = [...state.user.phone_code_numbers];
      const pIndex = phone_code_numbers.findIndex(p => p.id === phoneNumber.id);
      phone_code_numbers.splice(pIndex, 1);
      return {
        ...state,
        user: {
          ...state.user,
          phone_code_numbers
        },
        isUserLoaded: true
      }
    }

    default:
      return state;
  }
}
