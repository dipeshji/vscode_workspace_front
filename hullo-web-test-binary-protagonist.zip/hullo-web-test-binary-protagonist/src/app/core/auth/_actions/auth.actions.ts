import { Action } from '@ngrx/store';
import { User } from '../_models/user.model';

export enum AuthActionTypes {
  Login = '[Login] Action',
  Logout = '[Logout] Action',
  Register = '[Register] Action',
  UserRequested = '[Request User] Action',
  UserLoaded = '[Load User] Auth API',

  SaveProfile = '[SaveProfile] Action',
  addProfile ='[addProfile] Action',
  ChangePassword = '[ChangePassword] Action',

  UpdatePhoneNumber = '[UpdatePhoneNumber] Action',
  BuyPhoneNumber = '[BuyPhoneNumber] Action',
  ReleasePhoneNumber = '[ReleasePhoneNumber] Action',

  SaveSftpKey = '[SaveSftpKey] Action'
}

export class Login implements Action {
  readonly type = AuthActionTypes.Login;
  constructor(public payload: { authToken: string }) { }
}
export class addProfile implements Action {
  readonly type = AuthActionTypes.addProfile;
  constructor(public payload: {  userProfile: any }) { }
}
export class Logout implements Action {
  readonly type = AuthActionTypes.Logout;
}

export class Register implements Action {
  readonly type = AuthActionTypes.Register;
  constructor(public payload: { authToken: string }) { }
}

export class UserRequested implements Action {
  readonly type = AuthActionTypes.UserRequested;
}

export class UserLoaded implements Action {
  readonly type = AuthActionTypes.UserLoaded;
  constructor(public payload: { user: User }) { }
}

export class SaveProfile implements Action {
  readonly type = AuthActionTypes.SaveProfile;
  constructor(public payload: { account: any, user: any }) { }
}

export class ChangePassword implements Action {
  readonly type = AuthActionTypes.ChangePassword;
}

export class UpdatePhoneNumber implements Action {
  readonly type = AuthActionTypes.UpdatePhoneNumber;
  constructor(public payload: { phoneNumber: any }) { }
}

export class BuyPhoneNumber implements Action {
  readonly type = AuthActionTypes.BuyPhoneNumber;
  constructor(public payload: { phoneNumber: any }) { }
}

export class ReleasePhoneNumber implements Action {
  readonly type = AuthActionTypes.ReleasePhoneNumber;
  constructor(public payload: { phoneNumber: any }) { }
}

export class SaveSftpKey implements Action {
  readonly type = AuthActionTypes.SaveSftpKey;
  constructor(public payload: { data: any}) { }
}

export type AuthActions = addProfile | Login | Logout | Register | UserRequested | UserLoaded | SaveProfile | ChangePassword |
            UpdatePhoneNumber | BuyPhoneNumber | ReleasePhoneNumber | SaveSftpKey;
