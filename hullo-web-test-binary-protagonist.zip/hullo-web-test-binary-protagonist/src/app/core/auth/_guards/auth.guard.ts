// Angular
import { Injectable } from "@angular/core";
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
  CanActivateChild,
} from "@angular/router";
// RxJS
import { Observable } from "rxjs";
import { tap } from "rxjs/operators";
// NGRX
import { select, Store } from "@ngrx/store";
// Auth reducers and selectors
import { AppState } from "../../../core/reducers/";
import { isLoggedIn } from "../_selectors/auth.selectors";
import { getUserProfile } from "../_selectors/auth.selectors";

import { currentAuthToken } from "../_selectors/auth.selectors";
import { AuthService } from "../../auth/_services/auth.service";
import { addProfile, Logout } from "../../../core/auth/_actions/auth.actions";
import { currentUser } from "../../../core/auth/_selectors/auth.selectors";
import { User } from "./../_models/user.model";
import { environment } from "src/environments/environment";

@Injectable()
export class AuthGuard implements CanActivateChild {
  constructor(
    private auth: AuthService,
    private store: Store<AppState>,
    private router: Router
  ) {}

  canActivateChild(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean | Observable<boolean> | Promise<boolean> {
    console.log(environment.authTokenKey);
    if (!localStorage.getItem(environment.authTokenKey)) {
      console.log("On Route Change");
      this.router.navigate(["/auth/login"]);
      return false;
    }
    return new Promise((resolve) => {
      this.auth.getProfileData().subscribe(
        (resp: any) => {
          if (resp.user) {
            this.store.dispatch(new addProfile({ userProfile: resp.user }));
            resolve(true);
          } else {
            this.router.navigateByUrl("/auth/login");
          }
        },
        (err: any) => {
          console.log("err", err);
          this.router.navigateByUrl("/auth/login");
        }
      );
    });
  }
}
