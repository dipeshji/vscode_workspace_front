// Angular
import { Injectable } from "@angular/core";
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
} from "@angular/router";
// RxJS
import { Observable } from "rxjs";
import { tap } from "rxjs/operators";
// NGRX
import { select, Store } from "@ngrx/store";
// Auth reducers and selectors
import { AppState } from "../../../core/reducers/";
import { isLoggedIn } from "../_selectors/auth.selectors";
import { getUserProfile } from "../_selectors/auth.selectors";

import { currentAuthToken } from "../_selectors/auth.selectors";
import { AuthService } from "../../auth/_services/auth.service";
import { addProfile, Logout } from "../../../core/auth/_actions/auth.actions";
import { currentUser } from "../../../core/auth/_selectors/auth.selectors";
import { User } from "./../_models/user.model";
import { environment } from "src/environments/environment";

@Injectable({ providedIn: "root" })
export class LoggedIn implements CanActivate {
  constructor(
    private auth: AuthService,
    private store: Store<AppState>,
    private router: Router
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean | Observable<boolean> | Promise<boolean> {
    console.log(environment.authTokenKey);
    if (!localStorage.getItem(environment.authTokenKey)) {
      return true;
    }
    return new Promise((resolve) => {
      this.auth.getProfileData().subscribe(
        (resp: any) => {
          if (resp.user) {
            this.store.dispatch(new addProfile({ userProfile: resp.user }));
            this.router.navigateByUrl("/dashboard");
          } else {
            resolve(true);
          }
        },
        (err: any) => {
          console.log("err", err);
          resolve(true);
        }
      );
    });
  }
}
