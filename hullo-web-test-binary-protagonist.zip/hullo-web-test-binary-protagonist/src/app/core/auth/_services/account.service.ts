import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

const API_ACCOUNT_URL = '/updateaccount';
const API_CHANGE_PASSWORD_URL = '/changepwd';
const API_UPDATE_PHONENUMBER_URL = '/updatephonecode';
const API_RELEASE_PHONENUMBER_URL = '/twilio/releasenumber';
const API_BUY_PHONENUMBER_URL = '/twilio/buynumber';
const API_SUBSCRIPTION_PLAN_URL = '/subscription/plans';
const API_PURCHASE_SUBSCRIPTION_URL = '/subscription/purchase';
const API_SFTP_CONFIG_URL = '/awssftpcreateuser';

@Injectable()
export class AccountService {
  constructor(private http: HttpClient) { }

  updateAccount(user: any, account: any): Observable<any> {
    return this.http.post<any>(API_ACCOUNT_URL, { user, account });
  }

  changePassword(oldPassword: string, password: string): Observable<any> {
    const data = {
      old_password: oldPassword,
      password
    };
    return this.http.post<any>(API_CHANGE_PASSWORD_URL, data);
  }

  updatePhoneNumber(phoneNumber: any): Observable<any> {
    return this.http.post<any>(API_UPDATE_PHONENUMBER_URL, { phone_code_numbers: phoneNumber });
  }

  releasePhoneNumber(phoneNumber: any): Observable<any> {
    return this.http.post<any>(API_RELEASE_PHONENUMBER_URL, phoneNumber);
  }

  buyPhoneNumber(): Observable<any> {
    return this.http.post<any>(API_BUY_PHONENUMBER_URL, {});
  }

  getSubscriptionPlans(): Observable<any> {
    return this.http.get<any>(API_SUBSCRIPTION_PLAN_URL);
  }

  purchasePlans(data): Observable<any> {
    return this.http.post<any>(API_PURCHASE_SUBSCRIPTION_URL, data);
  }

  saveSftpKey(data): Observable<any> {
    return this.http.post<any>(API_SFTP_CONFIG_URL, data);
  }
}
