export class MenuConfig {
  public defaults: any = {
    header: {
      self: {},
      items: [
        {
          title: 'Dashboards',
          root: true,
          alignment: 'left',
          page: '/dashboard',
          translate: 'MENU.DASHBOARD',
        },
        {
          title: 'Applications',
          root: true,
          alignment: 'left',
          toggle: 'click',
          submenu: [
            {
              title: 'eCommerce',
              bullet: 'dot',
              icon: 'flaticon-business',
              permission: 'accessToECommerceModule',
              submenu: [
                {
                  title: 'Customers',
                  page: '/ecommerce/customers'
                },
                {
                  title: 'Products',
                  page: '/ecommerce/products'
                },
              ]
            },
            {
              title: 'User Management',
              bullet: 'dot',
              icon: 'flaticon-user',
              submenu: [
                {
                  title: 'Users',
                  page: '/user-management/users'
                },
                {
                  title: 'Roles',
                  page: '/user-management/roles'
                }
              ]
            },
          ]
        }
      ]
    },
    aside: {
      self: {},
      items: [
        {
          title: 'Dashboard',
          root: true,
          icon: 'flaticon2-architecture-and-city',
          page: '/dashboard',
          translate: 'MENU.DASHBOARD',
          bullet: 'dot',
        },
        {
          title: 'Account',
          root: true,
          icon: 'flaticon-user',
          page: '/account',
          bullet: 'dot',
          submenu: [
            {
              title: 'My Profile',
              page: '/account/profile'
            },
            {
              title: 'Phone Numbers',
              page: '/account/phone-numbers'
            },
            {
              title: 'SFTP',
              page: '/account/sftp'
            }
          ]
        },
        {
          title: 'Subscription',
          root: true,
          icon: 'flaticon-coins',
          page: '/subscription',
          translate: 'Subscription',
          bullet: 'dot',
        }
      ]
    },
  };

  public get configs(): any {
    return this.defaults;
  }
}
